using UnityEngine;
using UnityEngine.UI;


public class ManagerScore : MonoBehaviour
{
    public static ManagerScore Instance;
    
    public Text namePlusScore;
    public int highScore;

    private void Awake()
    {
        LoadScore();
        Instance = this;
    }

    private void Update()
    {
        namePlusScore.text = SaveName.Instance.refInputName + " " + MainManager.Instance.m_Points;        
    }
    private void SaveScore()
    {
        highScore = MainManager.Instance.m_Points;
        PlayerPrefs.SetInt("highScore", highScore);
    }    
    private void LoadScore()
    {
        highScore = PlayerPrefs.GetInt("highScore");
    }

    private void OnApplicationFocus(bool focus)
    {
        if (!focus)
        {
            SaveScore();
        }
    }
}
