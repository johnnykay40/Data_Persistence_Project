using UnityEngine;
using TMPro;

public class SaveName : MonoBehaviour
{
    public static SaveName Instance;
    public TMP_InputField inputName;

    public string refInputName;

    private void Awake()
    {
        Instance = this;
    }
    public void EqualsName()
    {
        refInputName = inputName.text;
    }    
}
